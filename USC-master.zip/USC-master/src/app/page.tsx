
// sections
import Hero from "./hero";
import SponsoredBy from "./sponsored-by";
import AboutEvent from "./about-event";
import OurStats from "./our-stats";
import EventContent from "./event-content";
import Faq from "./faq";
//import MusaCopy from "./musa-copy";
import Cta from "@/src/app/cta";
import ChallengeDefinition from "@/src/app/challenge-definition";
import EventDescription from "@/src/app/event-description";
import PreviousEditionCarousel from "@/src/app/previous-edition-carousel";
import { Navbar } from "@/src/components";
import Popup from "@/src/app/popup";
import {Suspense} from "react";
import BeingToldAboutUsCarousel from "@/src/app/being-told-about-as";

export default function Portfolio() {
    return (
        <>
            <Navbar />
            <Hero />
            <EventDescription />
            <SponsoredBy />
            <AboutEvent />
            <ChallengeDefinition />
            <OurStats />
            <BeingToldAboutUsCarousel />
            <PreviousEditionCarousel />
            <EventContent />
            <Faq />
            <Cta />
            {/* <MusaCopy /> */}
            <Suspense fallback={null}>
                <Popup />
            </Suspense>
        </>
    );
}
