"use client";

import React, { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import {
    Dialog,
    DialogHeader,
    DialogBody,
    DialogFooter,
    Button
} from "@material-tailwind/react";

export default function Popup() {
    const [open, setOpen] = useState(false);
    const searchParams = useSearchParams();

    // Toggle the Dialog
    const handleOpen = () => setOpen((cur) => !cur);

    useEffect(() => {
        // Check URL param (?popup=1) and localStorage to ensure it only shows once.
        const popupParam = searchParams.get("popup");
        const hasSeenPopup = localStorage.getItem("hasSeenPopup");

        if (popupParam === "1" && !hasSeenPopup) {
            setOpen(true);
            localStorage.setItem("hasSeenPopup", "true");
        }
    }, [searchParams]);

    return (
        <>
            <Dialog open={open} handler={handleOpen}>
                <DialogHeader>
                    Thank You!
                </DialogHeader>

                <DialogBody divider className="flex flex-col items-center">

                    <p>
                        Thank you for applying! We appreciate your interest and will
                        get back to you soon.
                    </p>
                </DialogBody>

                <DialogFooter>
                    <Button variant="gradient" onClick={handleOpen}>
                        Close
                    </Button>
                </DialogFooter>
            </Dialog>
        </>
    );
}
