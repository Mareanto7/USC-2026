"use client";
// components
import { Card, CardBody, Typography } from "@material-tailwind/react";
import { Navbar } from "@/src/components";

// sections
// import TallyForm from "../../components/tally-form";

export default function Portfolio() {
    return (
        <>
            <Navbar forceScrolling={true} />
            <section className="container mx-auto flex flex-col items-center my-12">
                <Card className="w-full mx-auto min-h-screen shadow-none">
                    <CardBody className="p-8 flex flex-col items-center justify-center">
                        <Typography variant="h2" color="blue-gray" className="mb-4 text-center font-bold">
                            Applications are Closed
                        </Typography>
                        <Typography variant="h6" color="blue-gray" className="text-center font-medium">
                            Thank you for your interest in the University Startup Challenge.
                        </Typography>
                        <Typography variant="paragraph" color="gray" className="mt-4 text-center">
                            The application period has ended
                        </Typography>
                    </CardBody>
                </Card>
            </section>
            {/* Original code commented out below
            <section className="container mx-auto flex flex-col items-center my-12">
                <Card className="w-full mx-auto min-h-screen shadow-none">
                    <CardBody className={"p-0"}>
                        <TallyForm />
                    </CardBody>
                </Card>
            </section>
            */}
        </>
    );
}
