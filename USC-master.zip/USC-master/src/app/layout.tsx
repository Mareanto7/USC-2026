import "./globals.css";
import type { Metadata } from "next";
import { Roboto } from "next/font/google";
import {Footer, Layout, Navbar} from "@/src/components";
import dictionary from "@/dictionaries/landing_page.json";
import { SpeedInsights } from "@vercel/speed-insights/next"
import {Analytics} from "@vercel/analytics/react";
import CookieBanner from "@/src/components/cookie-banner";

const roboto = Roboto({
  subsets: ["latin"],
  weight: ["300", "400", "500", "700", "900"],
  display: "swap",
});

export const metadata: Metadata = {
  title: dictionary.meta.title,
  description: dictionary.meta.description,
  keywords: dictionary.meta.keywords,
  icons: [
      "/icon.png"
  ]
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
    <head>
      <link rel="shortcut icon" href="/images/favicon.ico"/>
      <link rel="icon" href="/favicon.ico" sizes="any"/>
      <link rel="apple-touch-icon" sizes="180x180" href="/images/apple-touch-icon.png"/>
      <link rel="icon" type="image/png" sizes="32x32" href="/images/favicon-32x32.png"/>
      <link rel="icon" type="image/png" sizes="16x16" href="/images/favicon-16x16.png"/>
      <script
          defer
          data-site="YOUR_DOMAIN_HERE"
          src="https://api.nepcha.com/js/nepcha-analytics.js"
      ></script>
    </head>
    <body className={roboto.className}>
    <Layout>
      {children}
      <CookieBanner />
      <Footer />
      <Analytics />
      <SpeedInsights />
    </Layout>
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
        integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
        crossOrigin="anonymous"
        referrerPolicy="no-referrer"
    />
    </body>
    </html>
  );
}
