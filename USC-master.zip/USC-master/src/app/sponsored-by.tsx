"use client";

import Image from "next/image";
import { Typography } from "@material-tailwind/react";
import dictionary from "@/dictionaries/landing_page.json";
import Link from "next/link";
import { Element } from "react-scroll";

export function SponsoredBy() {
    return (
        <section className="py-8 px-8 lg:py-20" id="partners">
            <Element name="partners-element">
                <Typography variant="h3" className="text-center" color="blue-gray">
                    Sponsored By USC 2026
                </Typography>
            </Element>
            <div className="container mx-auto text-center mt-6 flex flex-col items-center">
                {dictionary.partners.map((group, key) => (
                    <div key={key} className="md:mb-8 w-4/5">
                        {group.partners.filter((partner) => partner.status === "confirmed").length > 0 && (
                            <Typography variant="h5" color="blue-gray" className="mb-12">
                                {group.partnersGroup}
                            </Typography>
                        )}
                        <div className="flex flex-wrap items-center justify-center gap-x-2 gap-y-8 md:gap-y-8 md:gap-x-8">
                            {group.partners.map(
                                (partner, key) =>
                                    partner.status === "confirmed" && (
                                        <Link href={partner.url} target="_blank" key={key}>
                                            <div className="w-56 h-32 relative">
                                                <Image
                                                    src={`/logos/${partner.logo}`}
                                                    alt={partner.name}
                                                    fill
                                                    className="object-contain"
                                                    sizes="(max-width: 224px) 100vw, (max-width: 224px) 33vw, 20vw"
                                                />
                                            </div>
                                        </Link>
                                    )
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </section>
    );
}

export default SponsoredBy;
