'use client';
import { Typography, Button } from "@material-tailwind/react";

import dictionary from "@/dictionaries/landing_page.json";
import Link from "next/link";
import * as links from "@/lib/links";

export function CallToAction() {
  return (
      <section className="container mx-auto flex flex-col items-center px-4 py-10">
      <div className="flex !w-full py-10 mb-5 md:mb-20 flex-col justify-center !items-center bg-gradient-to-r from-primary-500 to-secondary-900 max-w-6xl mx-auto rounded-2xl p-5 ">
        <Typography
            className="text-2xl md:text-3xl text-center font-bold "
            color="white"
        >
            {dictionary.call_to_action.title}
        </Typography>
        <Typography
            color="white"
            className=" md:w-7/12 text-center my-3 !text-base"
        >
            {dictionary.call_to_action.subtitle}
        </Typography>
        <div className="mt-2 flex-col md:flex-row w-full md:w-fit">
          <Button color="white" size="md" fullWidth disabled>
            <Link href={links.LinkApplyNow} target={"_blank"} className={"w-full md:w-fit"}>
            Apply Now
            </Link>
          </Button>


        </div>
      </div>
      </section>
  );
}

export default CallToAction;
