"use client";

import {Typography} from "@material-tailwind/react";
import dictionary from "@/dictionaries/landing_page.json";
import {Button} from "@material-tailwind/react";
import Link from "next/link";
import {LinkFullChallengeDescription} from "@/lib/links";

const ChallengeDefinition = () => {
    return (
        <section
            className="container mx-auto lg:px-16 grid gap-10 px-8 py-12 lg:grid-cols-1 lg:gap-20 xl:grid-cols-2 xl:place-items-center text-center md:text-left">
            <div className={""}>
                <Typography variant="h6" color="orange" className="mb-6 font-medium">
                    {dictionary.challenge_definition.subtitle}
                </Typography>
                <Typography
                    className="text-3xl font-bold leading-tight lg:w-3/4"
                    color="blue-gray"
                >
                    {dictionary.challenge_definition.title}
                </Typography>
                <Typography
                    variant="h4"
                    className="mt-3 w-full !text-gray-500 lg:w-9/12"
                >
                    {dictionary.challenge_definition.description}
                </Typography>
            </div>
            <div className={"flex flex-col items-center justify-center"}>
                <Button size="lg" variant={"outlined"} ripple disabled className={"flex items-center gap-6 md:p-6 text-gray-900 justify-self-end 2xl:justify-self-center"}>
                    Challenge materials
                    <i className="fa-regular fa-2x fa-file"></i>
                </Button>
             </div>
        </section>
    )
}

export default ChallengeDefinition;