"use client";

import { Typography } from "@material-tailwind/react";
import AboutCard from "@/src/components/about-card";

import dictionary from "@/dictionaries/landing_page.json";

const EVENT_INFO = [
  {
    title: "Cutting-Edge Insights!",
    description:
      "Gain deep insights into the latest AI trends, developments, and applications that are reshaping industries worldwide. ",
    subTitle: "Presentation",
      bgImage: "bg-gradient-to-r from-purple-500 to-pink-500",
  },
  {
    title: "Practical Knowledge!",
    description:
      "Attend workshops and hands-on sessions to acquire practical skills that you can apply immediately.",
    subTitle: "Workshops",
      bgImage: "bg-gradient-to-r from-purple-500 to-pink-500",

  },
];

const cards = () => {
    // if odd the last card will be full width
    const isOdd = dictionary.about_event.cards.length % 2 !== 0;
    return dictionary.about_event.cards.map((props, idx) => (
        <div key={idx} className={isOdd && idx === dictionary.about_event.cards.length - 1 ? "md:col-span-2" : ""}>
            <AboutCard bgImage={"bg-gradient-to-r from-primary-500 to-secondary-900"} {...props} />
        </div>
    ));
}

export function AboutEvent() {
  return (
    <section className="container mx-auto flex flex-col items-center px-4 py-10" id={"about-event"}>
      <Typography variant="h6" className="text-center mb-2" color="orange">
          {dictionary.about_event.subtitle}
      </Typography>
      <Typography variant="h3" className="text-center" color="blue-gray">
          {dictionary.about_event.title}
      </Typography>
      <Typography
        variant="lead"
        className="mt-2 lg:max-w-4xl mb-8 w-full text-center font-normal !text-gray-500"
      >
          {dictionary.about_event.description}
      </Typography>
      <div className="mt-8 w-full grid grid-cols-1 md:grid-cols-2 gap-4 ">
            {cards()}
{/*        {EVENT_INFO.map((props, idx) => (
          <AboutCard key={idx} {...props} />
        ))}
        <div className="md:col-span-2">
          <AboutCard
            title="Networking!"
            subTitle="Community"
            description="Connect with industry leaders, AI experts, and fellow enthusiasts to build valuable professional relationships."
            bgImage="bg-gradient-to-r from-purple-500 to-pink-500"
            />
        </div>*/}
      </div>
    </section>
  );
}

export default AboutEvent;
