'use client';
import {Typography} from "@material-tailwind/react";
import dictionary from "@/dictionaries/landing_page.json";
import { Element} from 'react-scroll'


const EventDescription = () => {
    return (
        <section className="container mx-auto flex flex-col items-center px-4 py-10">
            <Element name={"event-def-element"}>
        <Typography variant="h2" color="blue-gray" className="text-center mt-10 text-3xl">
            {dictionary.event_description.title}
        </Typography>
            </Element>
        </section>
    )
}

export default EventDescription;