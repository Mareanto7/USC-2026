'use client';
import {Carousel, Typography} from "@material-tailwind/react";
import React from "react";
import dictionary from "@/dictionaries/landing_page.json";
import Link from "next/link";

const BeingToldAboutUsCarousel = () => {

    return (
        <section className="container flex flex-col items-center max-w-3xl mx-auto lg:ml-4 xl:mx-auto text-center md:text-left pb-5">
            <Typography variant="h6" color="orange" className="mb-6 font-medium">
                Being told about us
            </Typography>
            <Carousel
                className="rounded-xl"
                autoplay={true}
                loop={true}
                autoplayDelay={7000}
                navigation={({setActiveIndex, activeIndex, length}) => (
                    <></>
                )}
            >
                {dictionary.quotes.map((q, idx) => (

                    <figure className="max-w-screen-md mx-auto text-center" key={idx}>
                        <svg className="w-4 h-4 mx-auto mb-3 text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 18 14">
                            <path d="M6 0H2a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4v1a3 3 0 0 1-3 3H2a1 1 0 0 0 0 2h1a5.006 5.006 0 0 0 5-5V2a2 2 0 0 0-2-2Zm10 0h-4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h4v1a3 3 0 0 1-3 3h-1a1 1 0 0 0 0 2h1a5.006 5.006 0 0 0 5-5V2a2 2 0 0 0-2-2Z"/>
                        </svg>
                        <blockquote>
                            <p className="text-2xl italic font-medium text-gray-900">{q.quote}</p>
                        </blockquote>
                        <figcaption className="flex items-center justify-center mt-6 space-x-3 rtl:space-x-reverse">
                            <div className="flex items-center divide-x-2 rtl:divide-x-reverse divide-gray-500">
                                <cite className="pe-3 font-medium text-gray-900">
                                    <Link href={q.link} target="_blank">{q.author}</Link>
                                </cite>
                            </div>
                        </figcaption>
                    </figure>

                    ))}
            </Carousel>
        </section>
)
}

export default BeingToldAboutUsCarousel;