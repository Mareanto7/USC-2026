"use client";

import React from "react";
import { Typography } from "@material-tailwind/react";
import Image from "next/image";

export function MusaCopy() {
    return (
        <section className="py-8 px-8 lg:py-20">
            <div className="container flex flex-col mx-auto gap-8">
                <div className="text-center">
                    <Typography variant="h3" color="blue-gray" className="mb-4">
                        The Reference Ecosystem and the role of{" "}
                        <span className="text-red-500">MUSA</span>
                    </Typography>
                    <Typography
                        variant="lead"
                        className="mx-auto lg:w-3/5 !text-gray-500"
                    >
                        <span className="font-bold">University Startup Challenge 2025</span>{" "}
                        has been implemented by Entrepreneurship Clubs and supported by B4i -
                        Bocconi for Innovation and{" "}
                        <span className="font-bold underline">MUSA</span>{" "}
                        <span className="font-bold">Multilayered Urban Sustainability Action</span>{" "}
                        - PNRR, Mission 4, component 2, investment 1.5, the innovation ecosystem funded by the
                        Italian Ministery for University and Research as part of Piano Nazionale di
                        Ripresa e Resilienza (PNRR).
                    </Typography>
                </div>
                <div className="w-full md:w-2/3 mx-auto">
                    <Image
                        src="/images/future-founders-musa-v2.jpg"
                        alt="footer musa"
                        width={1340}
                        height={220}
                        className="object-contain"
                        sizes="(max-width: 224px) 100vw, (max-width: 224px) 33vw, 20vw"
                    />
                </div>
                <div className="text-center pt-8">
                    <Typography variant="h3" color="blue-gray" className="mb-4">
                        With the patronage of{" "}Comune di Milano
                    </Typography>
                </div>
                <div className="w-full md:w-2/3 mx-auto p-2">
                    <div className="relative w-36 h-36 mx-auto">
                        <Image
                            src="/logos/partners/comune_di_milano.png"
                            alt="comune di milano"
                            fill
                            style={{ objectFit: 'contain' }}
                            sizes="(max-width: 224px) 100vw, (max-width: 224px) 33vw, 20vw"
                        />
                    </div>
                </div>
            </div>
        </section>
    );
}

export default MusaCopy;
