"use client";

import { Button, Typography } from "@material-tailwind/react";

import dictionary from "@/dictionaries/landing_page.json";
import Link from "next/link";
import {scroller } from 'react-scroll'
import * as links from "@/lib/links";

function Hero() {

  return (
    <div className="relative min-h-screen w-full bg-[url('/images/event.jpeg')] bg-cover bg-no-repeat bg-center">
    <div className="absolute inset-0 h-full w-full bg-gray-900/60" />
    <div className="grid min-h-screen px-8">
      <div className="container relative z-10 my-auto mx-auto grid place-items-center text-center custombp:mt-20">
        <Typography variant="h3" color="white" className="mb-2">
          {dictionary.hero.subtitle}
        </Typography>
        <Typography variant="h1" className="lg:max-w-3xl" color={"white"}>
          {dictionary.hero.title}
        </Typography>
        <Typography
            variant="lead"
            color="white"
            className="mt-1 mb-12 w-full md:max-w-full lg:max-w-2xl"
        >
          {dictionary.hero.description}
        </Typography>
        <div className="flex flex-col items-center gap-4 custombp:mb-20">
          <Button variant="gradient" color="white" disabled>
          <Link href={links.LinkApplyNow} target={"_blank"}>
            Apply Now
            </Link>
          </Button>
          <Typography variant="h6" color="white">{dictionary.call_to_action.subtitle}</Typography>
        </div>
        <button className="bg-gray-600/60 p-4 rounded-full mb-8 mt-3 md:mt-14 self-end" onClick={() => {    scroller.scrollTo('event-def-element', {
          duration: 1000,
          delay: 0,
          smooth: 'easeInOutQuart',
          offset: -100
        })}}>
          <i className=" fa-solid fa-chevron-down fa-2xl text-white"></i>
        </button>

      </div>
    </div>
    </div>
  );
}

export default Hero;
