"use client";

import {
    Tab,
    Tabs, TabsBody,
    TabsHeader,
    TabPanel, List, ListItem, Typography, AccordionHeader, AccordionBody, Accordion, Card, CardBody,
} from "@material-tailwind/react";


import dictionary from "@/dictionaries/landing_page.json";
import React from "react";

export function EventContent() {

    const [open, setOpen] = React.useState(-1);
    const handleOpen = (value: number) => setOpen(open === value || open === -1 ? 0 : value);


  return (
    <section className="py-8 px-8 lg:py-20">
      <Typography variant="h6" className="text-center mb-2" color="orange">
        {dictionary.agenda.subtitle}
      </Typography>
      <Typography variant="h3" className="text-center mb-6" color="blue-gray">
        {dictionary.agenda.title}
      </Typography>
      <Tabs value="Day1" className="mb-8">
        <div className="w-full flex mb-8 flex-col items-center gap-2">
          <TabsHeader className="h-20 md:h-12 w-full md:w-96 shadow-md">
              <Tab value="Day1" className="font-medium" onClick={() => setOpen(-1)}>
                  April 13th
              </Tab>
            <Tab value="Day2" className="font-medium" onClick={() => setOpen(-1)}>
              April 17th
            </Tab>
            <Tab value="Day3" className="font-medium" onClick={() => setOpen(-1)}>
              April 18th
            </Tab>
            <Tab value="Day4" className="font-medium" onClick={() => setOpen(-1)}>
              May 9th
            </Tab>
          </TabsHeader>
          <TabsBody
              animate={{
                initial: { y: 250 },
                mount: { y: 0 },
                unmount: { y: 250 },
              }}
              className={"w-full md:w-3/4 lg:w-1/2"}
          >
            {dictionary.agenda.schedule.map((dayAgenda, idx) => (
                <TabPanel key={idx} value={`Day${idx + 1}`} className={"p-0 flex flex-col"}>
                    <Card
                        className={"w-fit place-self-center text-center mb-4 transition-all outline-none bg-blue-gray-50/50 text-blue-gray-700 cursor-default"}>
                        <CardBody>
                            <Typography variant="h5" color="blue-gray"
                                        className="text-sm md:text-base grow">
                                <i className="fa-solid fa-lg fa-map-location-dot mr-3"/>{dayAgenda.location}
                            </Typography>
                        </CardBody>
                    </Card>
                    <List className={"p-0 md:p-4"}>
                        {dayAgenda.events.map((event, idx) => (
                            <ListItem key={idx} selected
                                      ripple={event.sub_events !== undefined && event.sub_events.length > 0}
                                      className={`${event.sub_events === undefined || event.sub_events.length === 0 ? "cursor-default" : ""}`}>
                                <Accordion
                                    open={open === idx + 1 || open === -1}
                                    onClick={() => handleOpen(idx + 1)}
                                >
                                    <AccordionHeader
                                        className={`${event.sub_events === undefined || event.sub_events.length === 0 ? "cursor-default" : ""} text-gray-900 border-0 w-full py-0 h-14`}>
                                        <div
                                            className={"w-full flex flex-row absolute place-items-center px-1 md:px-4"}>
                                            <Typography variant="h6" color="blue-gray"
                                                        className={"text-sm md:text-base w-16 md:w-32 flex-none"}>
                                                {event.time}
                                            </Typography>
                                            <Typography variant="h5" color="blue-gray"
                                                        className="line-clamp-3 text-sm md:text-base grow">
                                                {event.title}
                                            </Typography>
                                            <Typography variant="h6" color="blue-gray"
                                                        className={"line-clamp-3 text-right text-[10px] md:text-sm w-20 md:w-36 mr-0 flex-none"}>
                                                {event.place}
                                            </Typography>
                                        </div>
                                    </AccordionHeader>
                                    {event.sub_events !== undefined && event.sub_events.length > 0 && (
                                        <AccordionBody className={"flex flex-col gap-4 px-2 md:px-4"}>
                                            {event.sub_events.map((sub_event, idx) => (
                                                <Typography
                                                    key={idx}
                                                    color="blue-gray"
                                                    variant="paragraph"
                                                    className={"text-xs md:text-base"}
                                                >
                                                    {sub_event}
                                                </Typography>
                                            ))
                                            }
                                        </AccordionBody>
                                    )}
                                </Accordion>
                            </ListItem>
                        ))}
                    </List>
                </TabPanel>

            ))}
          </TabsBody>
        </div>
      </Tabs>
    </section>
  );
}

export default EventContent;
