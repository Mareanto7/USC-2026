import React from "react";
import {
  Navbar as MTNavbar,
  Collapse,
  Button,
  IconButton,
  Typography,
  MenuItem, List, ListItem, Menu, MenuHandler, MenuList,
} from "@material-tailwind/react";
import { XMarkIcon, Bars3Icon, ChevronDownIcon, BriefcaseIcon, RocketLaunchIcon, LightBulbIcon } from "@heroicons/react/24/solid";
import Link from "next/link";
import Image from "next/image";

// Replace these with your actual imports
import { logoUSC } from "@/lib/files";
import { homePage } from "@/lib/links";
import * as links from "@/lib/links";

export function Navbar({ forceScrolling = false }) {
  const [open, setOpen] = React.useState(false);
  const [isScrolling, setIsScrolling] = React.useState(false);

  const handleOpen = () => setOpen((cur) => !cur);

  // Close the mobile menu if the screen size is above 960px.
  React.useEffect(() => {
    function handleResize() {
      if (window.innerWidth >= 960) {
        setOpen(false);
      }
    }
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Conditionally attach/detach scroll behavior based on the disableScrolling prop.
  React.useEffect(() => {
    if (forceScrolling) {
      // If scrolling is disabled, ensure it's always "not scrolling".
      setIsScrolling(true);
      return;
    }

    function handleScroll() {
      if (window.scrollY > 0) {
        setIsScrolling(true);
      } else {
        setIsScrolling(false);
      }
    }

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [forceScrolling]);

  // We only want "scrolling" styles if disableScrolling === false AND the user has scrolled.
  const scrolled = forceScrolling || isScrolling;

  const navListMenuItems = [
    {
      icon: BriefcaseIcon,
      title: "For Companies",
      description: "Take part, network and scout for talents",
      link: "https://tally.so/r/nPGkQb",
    },
    {
      icon: LightBulbIcon,
      title: "To be a Mentor",
      description: "Help teams shape their ideas",
      link: "https://tally.so/r/wgkLpl",
    },
    {
      icon: RocketLaunchIcon,
      title: "For Startups & Scaleups",
      description: "Book your spot to expose in the Startup Showcase",
      link: "https://tally.so/r/3NRdvB",
    },
  ];


  function NavListMenu() {
    const [isMenuOpen, setIsMenuOpen] = React.useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
    const renderItems = navListMenuItems.map(
        ({ icon, title, description, link }, key) => (
            <Link href={link} key={key}>
              <MenuItem className="flex items-center gap-3 rounded-lg">
                <div className={"flex items-center justify-center rounded-lg !bg-blue-gray-50 p-2 "}>
                  {" "}
                  {React.createElement(icon, {
                    strokeWidth: 2,
                    className: "h-6 text-gray-900 w-6",
                  })}
                </div>
                <div>
                  <Typography
                      variant="h6"
                      color="blue-gray"
                      className="flex items-center text-sm font-bold"
                  >
                    {title}
                  </Typography>
                  <Typography
                      variant="paragraph"
                      className="text-xs !font-medium text-blue-gray-500"
                  >
                    {description}
                  </Typography>
                </div>
              </MenuItem>
            </Link>
        ),
    );

    return (
        <div className={"mt-4 mb-6 p-0 lg:mt-0 lg:mb-0 lg:flex-row lg:p-1"}>
        <React.Fragment>
          <Menu
              open={isMenuOpen}
              handler={setIsMenuOpen}
              offset={{ mainAxis: 20 }}
              placement="bottom"
              allowHover={true}
          >
            <MenuHandler>
              <Typography as="div" variant="small" className="font-normal">
                <ListItem
                    className={`${scrolled ? "text-gray-900" : "text-gray-900 lg:text-white hover:text-gray-900 lg:hover:text-white"} flex items-center gap-2 py-2 pr-4 font-medium hover:bg-opacity-20`}
                    selected={isMenuOpen || isMobileMenuOpen}
                    onClick={() => setIsMobileMenuOpen((cur) => !cur)}
                >
                  <div className="font-bold uppercase font-sans">
                    Opportunities
                  </div>
                  <ChevronDownIcon
                      strokeWidth={2.5}
                      className={`hidden h-3 w-3 transition-transform lg:block ${
                          isMenuOpen ? "rotate-180" : ""
                      }`}
                  />
                  <ChevronDownIcon
                      strokeWidth={2.5}
                      className={`block h-3 w-3 transition-transform lg:hidden ${
                          isMobileMenuOpen ? "rotate-180" : ""
                      }`}
                  />
                </ListItem>
              </Typography>
            </MenuHandler>
            <MenuList className="hidden max-w-screen-xl rounded-xl lg:block">
              <ul className="grid grid-cols-3 gap-y-2 outline-none outline-0">
                {renderItems}
              </ul>
            </MenuList>
          </Menu>
          <div className="block lg:hidden">
            <Collapse open={isMobileMenuOpen}>{renderItems}</Collapse>
          </div>
        </React.Fragment>
        </div>
    );
  }


  return (
      <MTNavbar
          shadow={false}
          fullWidth
          blurred={false}
          color={scrolled ? "white" : "transparent"}
          className={`${
              scrolled ? "bg-tertiary-200" : "bg-transparent"
          } fixed top-0 z-50 border-0`}
      >
        <div className="container mx-auto flex items-center justify-between">
          <Link href={homePage} className="flex flex-row items-center gap-4">
            <div className="relative h-8 w-8 object-contain">
              <Image
                  src={logoUSC}
                  alt={"University Startup Challenge"}
                  fill
                  sizes={
                      "(max-width: 768px) 100vw," +
                      "(max-width: 1200px) 50vw, 33vw"
                  }
                  className="object-contain"
              />
            </div>
            <Typography color={scrolled ? "blue-gray" : "white"} className="text-lg font-bold">
              University Startup Challenge
            </Typography>
          </Link>
          {/* Desktop links */}
          <div className="hidden items-center gap-4 lg:flex">
            <NavListMenu />
              <Button color={scrolled ? "gray" : "white"} variant="text" disabled>
                  Challenge Materials
              </Button>
            <Button color={scrolled ? "deep-orange" : "white"} disabled>
              <Link href={links.LinkApplyNow} target="_blank">
                Apply Now
              </Link>
            </Button>
          </div>
          {/* Mobile menu button */}
          <IconButton
              variant="text"
              color={scrolled ? "gray" : "white"}
              onClick={handleOpen}
              className="ml-auto inline-block lg:hidden"
          >
            {open ? (
                <XMarkIcon strokeWidth={2} className="h-6 w-6" />
            ) : (
                <Bars3Icon strokeWidth={2} className="h-6 w-6" />
            )}
          </IconButton>
        </div>
        <Collapse open={open}>
          <div
              className={`${
                  scrolled ? "bg-transparent" : "bg-white"
              } container mx-auto mt-4 rounded-lg px-2 py-4`}
          >
            <NavListMenu />
            <div className="flex w-full flex-nowrap gap-4 items-center lg:hidden">
                <Button variant="gradient" fullWidth size="sm" color={"blue-gray"} disabled>
                    Challenge Materials
                </Button>
                <Button variant="gradient" fullWidth size="sm" color={"deep-orange"} disabled>
                  <Link href={links.LinkApplyNow} target="_blank" >
                    Apply Now
                  </Link>
                </Button>
            </div>
          </div>
        </Collapse>
      </MTNavbar>
  );
}

export default Navbar;
