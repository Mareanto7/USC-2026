export const secondaryTheme = {
    button: {
        defaultProps: {
            color: "secondary",
        },
        valid: {
            colors: ["secondary"],
        },
        styles: {
            variants: {
                filled: {
                    primary: {
                        background: "bg-secondary",
                        color: "text-white",
                    },
                },
                outlined: {
                    primary: {
                        border: "border border-secondary",
                        color: "text-secondary",
                    },
                },
                gradient: {
                    primary: {
                        background: "bg-secondary",
                        color: "text-white",
                    },
                },
                text: {
                    primary: {
                        color: "text-secondary",
                    },
                },
            },
        },
    },
};

export const primaryTheme = {
    button: {
        defaultProps: {
            color: "primary",
        },
        valid: {
            colors: ["primary"],
        },
        styles: {
            variants: {
                filled: {
                    primary: {
                        background: "bg-primary",
                        color: "text-white",
                    },
                },
                outlined: {
                    primary: {
                        border: "border border-primary",
                        color: "text-primary",
                    },
                },
                gradient: {
                    primary: {
                        background: "bg-primary",
                        color: "text-white",
                    },
                },
                text: {
                    primary: {
                        color: "text-primary",
                    },
                },
            },
        },
    },
};