'use client';
import { useState, useEffect } from 'react';
import {Button, Card, CardBody, Typography} from "@material-tailwind/react";

const CookieBanner = () => {
    const [isBannerVisible, setIsBannerVisible] = useState(false);

    useEffect(() => {
        const hasSeenBanner = document.cookie.includes('cookieBannerSeen=true');
        if (!hasSeenBanner) {
            setIsBannerVisible(true);
        }
    }, []);

    const acceptCookies = () => {
        document.cookie = 'cookieBannerSeen=true; path=/; max-age=' + 60 * 60 * 24 * 365;
        setIsBannerVisible(false);
    };

    if (!isBannerVisible) return null;

    return (
        <div className="fixed bottom-4 right-4 z-50">
            <Card className="max-w-sm">
                <CardBody>
                    <div className="flex flex-nowrap justify-between">

                    <Typography variant="h6" color="blue-gray">
                        We use cookies
                    </Typography>
                    <svg width="800px" height="800px" viewBox="0 0 24 24" fill="none"
                         className={"h-6 w-6 text-blue-gray-500 mr-2"}
                         xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M9 16H9.01M12 11H12.01M7 10H7.01M15 16H15.01M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C12 5.76142 13.7909 8 16 8C16 10.2091 18.2386 12 21 12Z"
                            stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    </div>
                    <Typography variant={"paragraph"} color="gray" className="mt-2">
                        Our website uses cookies and analytics to enhance your experience and improve our services. By
                        continuing to browse, you consent to our use of cookies and the collection of analytics data.
                    </Typography>
                    <div className="flex justify-end mt-4">
                        <Button onClick={acceptCookies} color={"deep-orange"}>
                            Accept
                        </Button>
                    </div>
                </CardBody>
            </Card>
        </div>
    );
};

export default CookieBanner;