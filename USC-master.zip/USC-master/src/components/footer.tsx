import { Typography, IconButton } from "@material-tailwind/react";

const CURRENT_YEAR = new Date().getFullYear();

import * as links from "@/lib/links";
import Link from "next/link";

const eclubs = ["Polimi", "Bocconi", "Statale", "Cattolica", "Bicocca", "Liuc", "Unipd", "UniTN"];
const eclubLinks = [
  links.linkEclubPolimi,
  links.linkEclubBocconi,
  links.linkEclubStatale,
  links.linkEclubCattolica,
  links.linkEclubBicocca,
  links.linkEclubLiuc,
  links.linkEclubUnipd,
  links.linkEclubUnitn
];


export function Footer() {
  return (
    <footer className="pb-5 p-10 md:pt-10">
      <div className="container flex flex-col mx-auto">
        <div className="flex flex-col md:flex-row items-center !justify-between">
          <Typography
            as="a"
            href={links.linkEclubVentures}
            target="_blank"
            variant="h6"
            className="text-gray-900 whitespace-nowrap"
          >
            E-Club Ventures
          </Typography>
          <ul className="flex flex-wrap justify-center my-4 md:my-0 w-full mx-auto items-center gap-4">
            {eclubs.map((club, index) => (
              <li key={index}>
                <Typography
                  as="a"
                  href={eclubLinks[index]}
                  variant="small"
                  color="white"
                  className="font-normal !text-gray-700 hover:!text-gray-900 transition-colors"
                  target={"_blank"}
                >
                  {club}
                </Typography>
              </li>
            ))}
          </ul>
          <div className="flex w-32 justify-center md:justify-end gap-2">
            <Link href={links.LinkInstagram} target="_blank">
            <IconButton size="sm" color="gray" variant="text">
              <i className="fa-brands fa-instagram text-lg" />
            </IconButton>
            </Link>
            <Link href={links.linkLinkedin} target="_blank">
            <IconButton size="sm" color="gray" variant="text">
              <i className="fa-brands fa-linkedin text-lg" />
            </IconButton>
            </Link>
          </div>
        </div>
        <Typography
          color="blue-gray"
          className="text-center mt-12 font-normal !text-gray-700"
        >
          &copy; {CURRENT_YEAR} by E-Club Ventures | Designed by{" "}
          <Link href={"https://github.com/MartinBronzo"} target="_blank">Martin B.</Link>
        </Typography>
      </div>
    </footer>
  );
}

export default Footer;
