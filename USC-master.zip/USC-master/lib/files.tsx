
export const logoUSC = "/logos/usc.svg"
export const logoEclubVentures = "/logos/eclubs/ventures.png"
export const logoEclubCattolica = "/logos/eclubs/eclub_cattolica.png"
export const logoEclubBocconi = "/logos/eclubs/bocconi.png"
export const logoEclubPolimi = "/logos/eclubs/polimi.png"
export const logoEclubUnimi = "/logos/eclubs/unimi.png"
export const logoEclubStatale = "/logos/eclubs/statale.png"


export const logoUniversityNetwork = "/logos/partners/un.png"
export const logoBuildVision = "/logos/partners/BuildVision.png"
export const logoLombardini22 = "/logos/partners/lombardini22.png"

export const logoB4i = "/logos/partners/b4i.svg"
export const logoPolihub = "/logos/partners/polihub.png"

export const logoFondazioneUnimi = "/logos/partners/fondazioneunimi.png"

export const carouselSrcs = [
    "/images/carousel/1.jpg",
    "/images/carousel/2.jpg",
    "/images/carousel/3.jpg",]