export const homePage = "/"
export const LinkInstagram = "https://www.instagram.com/universitystartupchallenge"
export const linkLinkedin = "https://www.linkedin.com/company/e-club-ventures/"

export const linkB4i = "https://www.b4i.unibocconi.it/"
export const linkPolihub = "https://www.polihub.it/"
export const linkEclubPolimi = "https://www.eclubpolimi.it/"

export const linkEclubBocconi = "https://www.eclubbocconi.com/"
export const linkEclubStatale = "https://www.eclubunimi.it/"
export const linkEclubVentures = "https://www.eclubventures.com/"

export const linkEclubCattolica = "https://www.instagram.com/eclubcattolica"
export const linkEclubBicocca = "https://www.instagram.com/eclub_bicocca"
export const linkEclubLiuc = "https://www.instagram.com/eclubliuc"
export const linkEclubUnipd = "https://www.linkedin.com/company/entrepreneurship-club-unipd"
export const linkEclubUnitn = "https://www.linkedin.com/company/eclubunitn/"

export const linkIBicocca = "https://ibicocca.unimib.it/"



export const linkBuildVision = "https://www.buildvision.it/"
export const linkLombardini22 = "https://www.lombardini22.com/"

export const linkUniversityNetwork = "https://www.universitynetwork.it/"

export const LinkApplyNow = "#"

export const LinkDetailedProgram = "https://drive.google.com/drive/folders/1DlmQD8UlL6qnLYzPm4bxRd6tGEGCd_hH"

export const LinkFullChallengeDescription = "https://drive.google.com/drive/folders/1DlmQD8UlL6qnLYzPm4bxRd6tGEGCd_hH"