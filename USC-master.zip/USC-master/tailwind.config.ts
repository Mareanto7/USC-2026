import type { Config } from "tailwindcss";
const withMT = require("@material-tailwind/react/utils/withMT");

const config: Config = withMT({
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    screens: {'custombp':
          {'raw': '(max-height: 700px)'}
    },
    colors: {
      'primary': {
        '50': '#fff3f1',
        '100': '#ffe5e0',
        '200': '#ffd1c7',
        '300': '#ffb1a0',
        '400': '#ff846a',
        '500': '#f85c3b',
        '600': '#e85030',
        '700': '#c13214',
        '800': '#a02c14',
        '900': '#842b18',
        '950': '#481207',
      },
      'secondary': {
        '50': '#f1f1ff',
        '100': '#e6e5ff',
        '200': '#cfd0ff',
        '300': '#aba8ff',
        '400': '#8278ff',
        '500': '#5b41ff',
        '600': '#461bff',
        '700': '#3609f8',
        '800': '#2d07d0',
        '900': '#2608aa',
        '950': '#100164',
      },
      'tertiary': {
        '50': '#f5f7f9',
        '100': '#e9ecf0',
        '200': '#d9dee4',
        '300': '#b4bfcb',
        '400': '#9fabbb',
        '500': '#8794aa',
        '600': '#75819b',
        '700': '#69728c',
        '800': '#595f74',
        '900': '#4a4f5e',
        '950': '#30323b',
      },

    }
  },
  plugins: [require('@tailwindcss/line-clamp')],

});

export default config;
